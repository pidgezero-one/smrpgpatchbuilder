"""Miscellaneous constants supporting the development of event scripts."""

TOTAL_SCRIPTS = 0x1000

TOTAL_PACKETS = 256
