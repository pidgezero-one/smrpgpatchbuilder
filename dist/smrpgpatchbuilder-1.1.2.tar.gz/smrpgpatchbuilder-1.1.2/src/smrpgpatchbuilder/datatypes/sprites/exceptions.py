"""Errors specific to sprite construction."""


class InvalidSpriteConstructionException(Exception):
    """Generic error in sprite assembly."""
