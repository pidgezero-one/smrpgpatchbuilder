""""Miscellaeous constants used for event and NPC action scripts."""

TOTAL_ROOMS = 510

TOTAL_SOUNDS = 0xA3

TOTAL_MUSIC = 0x4A

TOTAL_DIALOGS = 0x1000

TOTAL_WORLD_MAP_AREAS = 56

TOTAL_SHOPS = 25

TOTAL_PACKETS = 256
