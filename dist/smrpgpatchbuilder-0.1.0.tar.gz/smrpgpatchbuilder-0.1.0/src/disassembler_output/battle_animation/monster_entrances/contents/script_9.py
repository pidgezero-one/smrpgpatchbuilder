# ENT0009_READY_TO_ATTACK

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SpriteSequence(sequence=5, looping_off=True),
	UnknownCommand(bytearray(b'\x18\x00\x80')),
	SpriteSequence(sequence=5),
	PauseScriptUntilSpriteSequenceDone(),
	ResetSpriteSequence(),
	ReturnSubroutine()
])
