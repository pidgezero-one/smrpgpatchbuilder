from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_0_0X3505C6
from .contents.script_0 import script as script_0

bank = AnimationScriptBank(
	name = BEHAVIOUR_0_0X3505C6,
	start = 0x3505c6,
	end = 0x3505da,
	scripts = [
		script_0,
	]
)
