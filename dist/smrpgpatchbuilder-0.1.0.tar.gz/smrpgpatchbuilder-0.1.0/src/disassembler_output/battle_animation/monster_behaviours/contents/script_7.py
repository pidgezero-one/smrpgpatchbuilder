# behaviour_7_0x350796

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 12, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	SetOMEM60To072C(),
	ObjectQueueAtOffsetAndIndexAtAMEM60(target_address=0x351493),
	UnknownCommand(bytearray(b'<\x00\x08')),
	Jmp(["command_0x3505d5"])
])
