# behaviour_43_0x350E38

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 18, script = [
	ClearAMEM8Bit(0x60),
	SetOMEM60To072C(),
	DecAMEM16BitByConst(0x60, 64),
	ObjectQueueAtOffsetAndIndexAtAMEM60(target_address=0x351026),
	AttackTimerBegins(),
	UnknownCommand(bytearray(b'<\x00\x08')),
	ResetSpriteSequence(),
	Jmp(["command_0x350d31"])
])
