# PhysicalAttack18

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	PlaySound(sound=S0097_PLASMA_TOSS),
	RunSubroutine(["command_0x357d0b"]),
	RunSubroutine(["command_0x352f2f"]),
	RunSubroutine(["command_0x3523c4"]),
	RunSubroutine(["command_0x35789e"]),
	ReturnSubroutine()
])
