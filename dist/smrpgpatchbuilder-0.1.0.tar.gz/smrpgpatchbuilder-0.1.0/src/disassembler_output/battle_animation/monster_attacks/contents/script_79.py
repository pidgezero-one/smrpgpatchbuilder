# Multistrike

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x3577e2"]),
	SetOMEM60To072C(),
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	SpriteSequence(sequence=3),
	PauseScriptUntilSpriteSequenceDone(),
	PlaySound(sound=S0039_CLAW),
	ResetSpriteSequence(),
	RunSubroutine(["command_0x3577f2"]),
	RunSubroutine(["command_0x3523c4"]),
	ReturnSubroutine()
])
