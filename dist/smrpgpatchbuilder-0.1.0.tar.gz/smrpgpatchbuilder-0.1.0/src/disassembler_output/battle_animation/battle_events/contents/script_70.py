# BE0070_JINX_USES_JINXED

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(header=["command_0x3a6b93", "command_0x3a6b9a"], script = [
	RunSubroutine(["command_0x3a7531"]),
	RunSubroutine(["command_0x3aebbf"]),
	UnknownCommand(bytearray(b'\xe2')),
	RunSubroutine(["command_0x3a7531"], identifier="command_0x3a6b93"),
	RunSubroutine(["command_0x3aecbb"]),
	UnknownCommand(bytearray(b'\xe2')),
	RunSubroutine(["command_0x3a7531"], identifier="command_0x3a6b9a"),
	RunSubroutine(["command_0x3aecdc"]),
	UnknownCommand(bytearray(b'\xe2'))
])
