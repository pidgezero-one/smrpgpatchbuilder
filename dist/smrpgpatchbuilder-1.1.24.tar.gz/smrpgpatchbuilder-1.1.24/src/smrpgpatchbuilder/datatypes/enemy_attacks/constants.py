""""Miscellaeous constants used for enemy attack classes and functions."""

ENEMY_ATTACK_BASE_ADDRESS: int = 0x391226
ENEMY_ATTACK_NAME_ADDRESS: int = 0x3959F4
ENEMY_ATTACK_NAME_LENGTH: int = 13
