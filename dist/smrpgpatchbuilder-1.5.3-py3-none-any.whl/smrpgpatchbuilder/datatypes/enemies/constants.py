""""Miscellaeous constants used for enemy classes and functions."""

FLOWER_BONUS_BASE_ADDRESS = 0x39BB44

BASE_ENEMY_ADDRESS = 0x390226
BASE_REWARD_ADDRESS = 0x39162A
