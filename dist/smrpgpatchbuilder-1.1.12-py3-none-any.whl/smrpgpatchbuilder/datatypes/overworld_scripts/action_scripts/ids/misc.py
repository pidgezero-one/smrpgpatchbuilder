"""Miscellaneous constants supporting the development of action scripts."""

TOTAL_SCRIPTS = 0x400
