from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_1_0X3505DA
from .contents.script_1 import script as script_1

bank = AnimationScriptBank(
	name = BEHAVIOUR_1_0X3505DA,
	start = 0x3505da,
	end = 0x3505fe,
	scripts = [
		script_1,
	]
)
