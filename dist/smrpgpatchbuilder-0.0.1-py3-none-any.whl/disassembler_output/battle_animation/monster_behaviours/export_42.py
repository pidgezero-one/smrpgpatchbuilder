from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_42_0X350DED
from .contents.script_42 import script as script_42

bank = AnimationScriptBank(
	name = BEHAVIOUR_42_0X350DED,
	start = 0x350ded,
	end = 0x350e38,
	scripts = [
		script_42,
	]
)
