from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_20_0X3509D5
from .contents.script_20 import script as script_20

bank = AnimationScriptBank(
	name = BEHAVIOUR_20_0X3509D5,
	start = 0x3509d5,
	end = 0x350a01,
	scripts = [
		script_20,
	]
)
