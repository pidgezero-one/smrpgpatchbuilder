from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_32_0X350C14
from .contents.script_32 import script as script_32

bank = AnimationScriptBank(
	name = BEHAVIOUR_32_0X350C14,
	start = 0x350c14,
	end = 0x350c5b,
	scripts = [
		script_32,
	]
)
