from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_13_0X3508BA
from .contents.script_13 import script as script_13

bank = AnimationScriptBank(
	name = BEHAVIOUR_13_0X3508BA,
	start = 0x3508ba,
	end = 0x3508df,
	scripts = [
		script_13,
	]
)
