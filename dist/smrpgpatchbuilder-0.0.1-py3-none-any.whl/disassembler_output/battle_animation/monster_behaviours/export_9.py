from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_9_0X3507E9
from .contents.script_9 import script as script_9

bank = AnimationScriptBank(
	name = BEHAVIOUR_9_0X3507E9,
	start = 0x3507e9,
	end = 0x350830,
	scripts = [
		script_9,
	]
)
