from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_46_0X350E98
from .contents.script_46 import script as script_46

bank = AnimationScriptBank(
	name = BEHAVIOUR_46_0X350E98,
	start = 0x350e98,
	end = 0x350ed1,
	scripts = [
		script_46,
	]
)
