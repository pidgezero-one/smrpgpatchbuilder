# behaviour_53_0x350F7A

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 172, script = [
	SetOMEM60To072C(),
	JmpIfAMEM16BitEqualsConst(0x60, 0, ["command_0x351011"]),
	JmpIfAMEM16BitEqualsConst(0x60, 3, ["command_0x350ea6"]),
	JmpIfAMEM16BitEqualsConst(0x60, 4, ["command_0x35343e"]),
	JmpIfAMEM16BitEqualsConst(0x60, 5, ["command_0x35344c"]),
	JmpIfAMEM16BitEqualsConst(0x60, 6, ["command_0x350ed1"]),
	JmpIfAMEM16BitEqualsConst(0x60, 10, ["command_0x353652"]),
	JmpIfAMEM16BitEqualsConst(0x60, 11, ["command_0x35366a"]),
	JmpIfAMEM16BitEqualsConst(0x60, 12, ["command_0x35368a"]),
	JmpIfAMEM16BitEqualsConst(0x60, 13, ["command_0x3536aa"]),
	JmpIfAMEM16BitEqualsConst(0x60, 14, ["command_0x35317e"]),
	JmpIfAMEM16BitEqualsConst(0x60, 15, ["command_0x35318d"]),
	JmpIfAMEM16BitEqualsConst(0x60, 16, ["command_0x353194"]),
	JmpIfAMEM16BitEqualsConst(0x60, 17, ["command_0x35319b"]),
	JmpIfAMEM16BitEqualsConst(0x60, 18, ["command_0x3531a2"]),
	JmpIfAMEM16BitEqualsConst(0x60, 19, ["command_0x3531a8"]),
	JmpIfAMEM16BitEqualsConst(0x60, 20, ["command_0x3531ae"]),
	JmpIfAMEM16BitEqualsConst(0x60, 21, ["command_0x3531b4"]),
	JmpIfAMEM16BitEqualsConst(0x60, 22, ["command_0x3531ba"]),
	JmpIfAMEM16BitEqualsConst(0x60, 23, ["command_0x3531c0"]),
	JmpIfAMEM16BitEqualsConst(0x60, 24, ["command_0x3531ce"]),
	JmpIfAMEM16BitEqualsConst(0x60, 25, ["command_0x3531d4"]),
	JmpIfAMEM16BitEqualsConst(0x60, 26, ["command_0x3531da"]),
	JmpIfAMEM16BitEqualsConst(0x60, 27, ["command_0x3536ae"]),
	JmpIfAMEM16BitEqualsConst(0x60, 28, ["command_0x3536f3"]),
	JmpIfAMEM16BitEqualsConst(0x60, 32, ["command_0x3536b9"]),
	ClearAMEM8Bit(0x60, identifier="command_0x351011"),
	SetAMEM16BitToConst(0x60, 21),
	ObjectQueueAtOffsetAndIndex(index=6, target_address=0x353706),
	ObjectQueueAtOffsetAndIndex(index=8, target_address=0x353706),
	ObjectQueueAtOffsetAndIndex(index=10, target_address=0x353706),
	Jmp(["command_0x350e93"])
])
