# behaviour_48_0x350F1A

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 42, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	UnknownCommand(bytearray(b'T')),
	UnknownCommand(bytearray(b'>')),
	UnknownCommand(bytearray(b'W')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'U')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'V')),
	JmpIfTargetEnabled(["command_0x350f40"]),
	PlaySound(sound=S0089_COMMON_MONSTER_EXPLOSION),
	DrawSpriteAtAMEM32Coords(sprite_id=SPR0516_ENEMY_DEFEATED_EXPLOSION_STARS, sequence=0),
	SetAMEM8BitToConst(0x60, 40),
	SetOMEMCurrentToAMEM8Bit(omem=0x2D, amem=0x60),
	UnknownCommand(bytearray(b'\x1c ')),
	Pause1Frame(),
	Pause1Frame(),
	VisibilityOn(),
	PauseScriptUntilSpriteSequenceDone(),
	VisibilityOff(),
	UnknownCommand(bytearray(b'\x98')),
	GameOverIfNoAlliesStanding(identifier="command_0x350f40"),
	Jmp(["command_0x350e93"])
])
