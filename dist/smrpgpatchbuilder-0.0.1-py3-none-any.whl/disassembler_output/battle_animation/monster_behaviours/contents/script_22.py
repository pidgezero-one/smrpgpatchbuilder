# behaviour_22_0x350A3E

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 17, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	SetOMEM60To072C(),
	ObjectQueueAtOffsetAndIndexAtAMEM60(target_address=0x351493),
	UnknownCommand(bytearray(b'R\x80\x00O\n')),
	UnknownCommand(bytearray(b'<\x00\x08')),
	Jmp(["command_0x3509ae"])
])
