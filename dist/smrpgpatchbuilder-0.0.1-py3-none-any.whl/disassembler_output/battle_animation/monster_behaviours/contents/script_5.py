# behaviour_5_0x350737

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 34, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	UnknownCommand(bytearray(b'T')),
	UnknownCommand(bytearray(b'>')),
	UnknownCommand(bytearray(b'W')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'U')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'V')),
	JmpIfTargetEnabled(["command_0x350755"]),
	PlaySound(sound=S0089_COMMON_MONSTER_EXPLOSION),
	UnknownCommand(bytearray(b'\xa4')),
	SetAMEM8BitTo7E5x(0x60, 0x7E002C),
	ClearAMEM8Bit(0x61),
	ObjectQueueAtOffsetAndIndexAtAMEM60(target_address=0x350759),
	RemoveObject(),
	SetAMEMToAMEM16Bit(dest_amem=0x6E, upper=0x00, amem=0x62),
	UnknownCommand(bytearray(b'\x98')),
	GameOverIfNoAlliesStanding(identifier="command_0x350755"),
	Jmp(["command_0x3505d5"])
])
