# behaviour_6_0x350790

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 6, script = [
	VisibilityOff(identifier="command_0x350790"),
	UnknownCommand(bytearray(b'O')),
	Jmp(["command_0x3505c9"])
])
