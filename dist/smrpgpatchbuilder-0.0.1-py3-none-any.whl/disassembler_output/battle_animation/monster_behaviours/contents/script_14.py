# behaviour_14_0x350916

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 6, script = [
	VisibilityOff(identifier="command_0x350916"),
	UnknownCommand(bytearray(b'O')),
	Jmp(["command_0x3508a9"])
])
