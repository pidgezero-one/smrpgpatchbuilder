# behaviour_46_0x350E98

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 57, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	UnknownCommand(bytearray(b'T')),
	UnknownCommand(bytearray(b'n')),
	UnknownCommand(bytearray(b'>')),
	ResetSpriteSequence(),
	UnknownCommand(bytearray(b'W')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'U')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'V')),
	JmpIfTargetEnabled(["command_0x350ecd"]),
	PlaySound(sound=S0176_BOSS_FADE_OUT_DEATH, identifier="command_0x350ea6"),
	EnableSpritesOnSubscreen(),
	UnknownCommand(bytearray(b'\x84\x00\x08')),
	UnknownCommand(bytearray(b'\x9e\x00\x00')),
	FadeOutSprite(duration=2),
	PauseScriptUntil(condition=FADE_4BPP_COMPLETE),
	DisableSpritesOnSubscreen(),
	UnknownCommand(bytearray(b'\xa4')),
	RemoveObject(),
	PlaySound(sound=S0043_COIN_SHOWERS_INTO_FOUNTAIN),
	ClearAMEM8Bit(0x60),
	SetAMEM16BitToConst(0x60, 20),
	ClearAMEM8Bit(0x6F),
	ObjectQueueAtOffsetAndIndex(index=2, target_address=0x353706),
	PauseScriptUntilAMEMBitsSet(0x6F, [0]),
	SetAMEMToAMEM16Bit(dest_amem=0x6E, upper=0x00, amem=0x62),
	GameOverIfNoAlliesStanding(identifier="command_0x350ecd"),
	Jmp(["command_0x350e93"])
])
