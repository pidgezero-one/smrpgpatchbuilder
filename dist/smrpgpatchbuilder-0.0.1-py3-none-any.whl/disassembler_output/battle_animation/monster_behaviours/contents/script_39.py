# behaviour_39_0x350D9D

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 6, script = [
	VisibilityOff(identifier="command_0x350d9d"),
	UnknownCommand(bytearray(b'O')),
	Jmp(["command_0x350d25"])
])
