# behaviour_26_0x350AF7

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 54, script = [
	JmpIfTargetDisabled(["command_0x350bf3"]),
	VisibilityOn(identifier="command_0x350afa"),
	SetAMEM8BitTo7E5x(0x60, 0x7E002E),
	ClearAMEM8Bit(0x61),
	ObjectQueueAtOffsetAndIndexAtAMEM60(target_address=0x352128),
	UnknownCommand(bytearray(b'\x16')),
	MoveObject(speed=11, start_position=-161, end_position=160, apply_to_z=True, should_set_start_position=True, should_set_end_position=True, should_set_speed=True, identifier="command_0x350b06"),
	UnknownCommand(bytearray(b'\x12\x81')),
	SetAMEM40ToXYZCoords(origin=CASTER_INITIAL_POSITION, x=0, y=0, z=0, set_x=True),
	PauseScriptUntil(condition=UNKNOWN_PAUSE_1),
	ResetTargetMappingMemory(),
	UnknownCommand(bytearray(b'\x15')),
	MoveObject(speed=11, start_position=160, end_position=-161, apply_to_z=True, should_set_start_position=True, should_set_end_position=True, should_set_speed=True),
	UnknownCommand(bytearray(b'\x12A')),
	UnknownCommand(bytearray(b'\x15')),
	Pause1Frame(),
	Jmp(["command_0x350b06"])
])
