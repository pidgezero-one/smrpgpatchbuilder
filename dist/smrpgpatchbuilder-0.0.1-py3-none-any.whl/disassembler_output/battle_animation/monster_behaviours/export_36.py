from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_36_0X350D22
from .contents.script_36 import script as script_36

bank = AnimationScriptBank(
	name = BEHAVIOUR_36_0X350D22,
	start = 0x350d22,
	end = 0x350d36,
	scripts = [
		script_36,
	]
)
