from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_2_0X350635
from .contents.script_2 import script as script_2

bank = AnimationScriptBank(
	name = BEHAVIOUR_2_0X350635,
	start = 0x350635,
	end = 0x350669,
	scripts = [
		script_2,
	]
)
