from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_16_0X350928
from .contents.script_16 import script as script_16

bank = AnimationScriptBank(
	name = BEHAVIOUR_16_0X350928,
	start = 0x350928,
	end = 0x35096f,
	scripts = [
		script_16,
	]
)
