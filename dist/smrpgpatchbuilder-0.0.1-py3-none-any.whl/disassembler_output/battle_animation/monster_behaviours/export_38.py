from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_38_0X350D72
from .contents.script_38 import script as script_38

bank = AnimationScriptBank(
	name = BEHAVIOUR_38_0X350D72,
	start = 0x350d72,
	end = 0x350d9d,
	scripts = [
		script_38,
	]
)
