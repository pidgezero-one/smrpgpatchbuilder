from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_8_0X3507A2
from .contents.script_8 import script as script_8

bank = AnimationScriptBank(
	name = BEHAVIOUR_8_0X3507A2,
	start = 0x3507a2,
	end = 0x3507e9,
	scripts = [
		script_8,
	]
)
