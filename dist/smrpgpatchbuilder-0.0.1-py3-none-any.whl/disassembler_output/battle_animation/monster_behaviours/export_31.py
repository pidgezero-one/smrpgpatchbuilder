from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_31_0X350BFD
from .contents.script_31 import script as script_31

bank = AnimationScriptBank(
	name = BEHAVIOUR_31_0X350BFD,
	start = 0x350bfd,
	end = 0x350c0e,
	scripts = [
		script_31,
	]
)
