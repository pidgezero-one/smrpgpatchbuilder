from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_51_0X350F56
from .contents.script_51 import script as script_51

bank = AnimationScriptBank(
	name = BEHAVIOUR_51_0X350F56,
	start = 0x350f56,
	end = 0x350f6b,
	scripts = [
		script_51,
	]
)
