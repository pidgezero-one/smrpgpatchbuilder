from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_52_0X350F6B
from .contents.script_52 import script as script_52

bank = AnimationScriptBank(
	name = BEHAVIOUR_52_0X350F6B,
	start = 0x350f6b,
	end = 0x350f7a,
	scripts = [
		script_52,
	]
)
