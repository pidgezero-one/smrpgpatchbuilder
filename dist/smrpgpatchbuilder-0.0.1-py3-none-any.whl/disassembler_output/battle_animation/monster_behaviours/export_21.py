from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_21_0X350A38
from .contents.script_21 import script as script_21

bank = AnimationScriptBank(
	name = BEHAVIOUR_21_0X350A38,
	start = 0x350a38,
	end = 0x350a3e,
	scripts = [
		script_21,
	]
)
