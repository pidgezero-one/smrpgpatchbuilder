from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_28_0X350BB7
from .contents.script_28 import script as script_28

bank = AnimationScriptBank(
	name = BEHAVIOUR_28_0X350BB7,
	start = 0x350bb7,
	end = 0x350bf3,
	scripts = [
		script_28,
	]
)
