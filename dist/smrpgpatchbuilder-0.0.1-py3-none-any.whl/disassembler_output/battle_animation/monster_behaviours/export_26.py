from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_26_0X350AF7
from .contents.script_26 import script as script_26

bank = AnimationScriptBank(
	name = BEHAVIOUR_26_0X350AF7,
	start = 0x350af7,
	end = 0x350b2d,
	scripts = [
		script_26,
	]
)
