# Geno Boost

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x358086"]),
	RunSubroutine(["command_0x358127"]),
	RunSubroutine(["command_0x35907d"]),
	ReturnSubroutine()
])
