# Attack Up!

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	InitializeBonusMessageSequence(),
	DisplayBonusMessage(message=BM_ATTACK, x=0, y=-32),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=10),
	DisplayBonusMessage(message=BM_UP, x=2, y=-24),
	PauseScriptUntilBonusMessageComplete(),
	ReturnSubroutine()
])
