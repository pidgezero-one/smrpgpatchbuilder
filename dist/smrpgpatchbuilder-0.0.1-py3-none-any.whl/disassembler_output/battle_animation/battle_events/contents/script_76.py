# BE0076_SOLO_FIRE_CRYSTAL_APPEARS

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	PlaySound(sound=S0078_TIMED_STAT_BOOST),
	UnknownCommand(bytearray(b'\xba\x01\x00\x00')),
	ScreenEffect(SEF0015_UNKNOWN),
	UnknownCommand(bytearray(b'\xa8\x02\x00')),
	SetAMEM16BitToConst(0x60, 0),
	ObjectQueueAtOffsetAndIndex(index=10, target_address=0x3A8AC0),
	ObjectQueueAtOffsetAndIndex(index=12, target_address=0x3A8AC0),
	FadeCurrentMusicToVolume(speed=3, volume=0),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=60),
	PlayMusicAtCurrentVolume(M0021_SADSONG),
	FadeCurrentMusicToVolume(speed=5, volume=127),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ae3a8"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae414"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ae472"], bit_2=True, bit_4=True),
	Pause1Frame(),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ae4c5"], character_slot=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae552"], character_slot=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ae5e0"], character_slot=True, bit_4=True),
	RunSubroutine(["command_0x3a771e"]),
	Jmp(["command_0x3a7550"])
])
