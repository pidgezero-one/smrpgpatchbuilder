# BE0026_INTRO_SCENE_TENTACLES_RISE_FROM_HOLES

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	UnknownCommand(bytearray(b'\xba\x03\x03\x00\x00\x00x\xff')),
	ScreenEffect(SEF0013_SET_BATTLEFIELD_COORDS),
	UnknownCommand(bytearray(b'\x18\x00\x80')),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ac505"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ac51f"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ac539"], bit_2=True, bit_4=True),
	RunSubroutine(["command_0x3a771e"]),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=60),
	Jmp(["command_0x3a7550"])
])
