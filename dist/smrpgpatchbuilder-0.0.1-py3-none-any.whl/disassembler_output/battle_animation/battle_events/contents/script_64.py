# BE0064_UNUSED

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3adba6"], bit_2=True, bit_4=True),
	SetAMEM8BitTo7E1x(0x60, 0x7EE00F),
	JmpIfAMEM8BitEqualsConst(0x60, 5, ["command_0x3a6aa3"]),
	SpriteQueue(field_object=3, destinations=["queuestart_0x3adbc5"], bit_2=True, bit_4=True),
	Jmp(["command_0x3a6aa8"]),
	SpriteQueue(field_object=3, destinations=["queuestart_0x3adc54"], bit_2=True, bit_4=True, identifier="command_0x3a6aa3"),
	Jmp(["command_0x3a7550"], identifier="command_0x3a6aa8")
])
