# BE0092_SHELLY_BREAKS

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SetAMEM16BitToConst(0x60, 0),
	ObjectQueueAtOffsetAndIndex(index=8, target_address=0x3A8AC0),
	RunSubroutine(["command_0x3a771e"]),
	Jmp(["command_0x3a7550"])
])
