# BE0029_UNUSED

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ab97e"], character_slot=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ab97e"], character_slot=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ac80c"], character_slot=True, bit_4=True),
	UnknownCommand(bytearray(b'\xba\x03\x03\x00\x00\x01\x00\x00')),
	ScreenEffect(SEF0013_SET_BATTLEFIELD_COORDS),
	UnknownCommand(bytearray(b'\x18\x00\x80')),
	RunSubroutine(["command_0x3a771e"]),
	UnknownCommand(bytearray(b'[\x01\x00')),
	Jmp(["command_0x3a7550"])
])
