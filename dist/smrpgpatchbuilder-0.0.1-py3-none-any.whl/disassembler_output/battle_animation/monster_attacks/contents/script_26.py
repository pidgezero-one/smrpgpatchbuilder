# PhysicalAttack32

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	RunSubroutine(["command_0x357c57"]),
	PlaySound(sound=S0111_SLEDGE),
	SetAMEM16BitToConst(0x60, 16),
	RunSubroutine(["command_0x352489"]),
	RunSubroutine(["command_0x3577f2"]),
	AttackTimerBegins(),
	ReturnSubroutine()
])
