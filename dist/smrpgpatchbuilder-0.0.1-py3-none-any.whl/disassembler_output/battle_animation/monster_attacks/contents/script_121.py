

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SetOMEM60To072C(),
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	PlaySound(sound=S0169_TELEPORT_ATTACK),
	RunSubroutine(["command_0x357ebe"]),
	RunBattleEvent(script_id=BE0070_JINX_USES_JINXED, offset=4),
	RunSubroutine(["command_0x3535ad"]),
	RunSubroutine(["command_0x3577f2"]),
	ReturnSubroutine()
])
