# PhysicalAttack40

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SetOMEM60To072C(),
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	SetAMEM8BitTo7E1x(0x6F, 0x7EE00F),
	JmpIfAMEM8BitEqualsConst(0x6F, 1, ["command_0x351899"]),
	JmpIfAMEM8BitEqualsConst(0x6F, 2, ["command_0x35189d"]),
	RunSubroutine(["command_0x357b83"]),
	SpriteSequence(sequence=4, identifier="command_0x351899"),
	PauseScriptUntilSpriteSequenceDone(),
	ResetSpriteSequence(),
	PlaySound(sound=S0139_GUITAR_STRING, identifier="command_0x35189d"),
	PlaySound(sound=S0140_S_CROW_BELL),
	SetAMEM16BitToConst(0x60, 15),
	RunSubroutine(["command_0x352475"]),
	RunSubroutine(["command_0x3577f2"]),
	RunSubroutine(["command_0x35241b"]),
	ReturnSubroutine()
])
