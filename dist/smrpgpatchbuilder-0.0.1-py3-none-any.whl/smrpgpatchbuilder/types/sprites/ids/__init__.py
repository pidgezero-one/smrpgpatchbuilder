"""Miscellaneous constants supporting the development of sprites."""

from .sprite_ids import *

from .misc import TOTAL_SPRITES
