"""IDs for dialog banks"""

from .types import DialogBankID

DIALOG_BANK_22 = DialogBankID(0x22)
DIALOG_BANK_23 = DialogBankID(0x23)
DIALOG_BANK_24 = DialogBankID(0x24)
