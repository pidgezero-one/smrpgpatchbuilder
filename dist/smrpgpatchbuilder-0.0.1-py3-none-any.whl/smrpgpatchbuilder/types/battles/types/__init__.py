"""Misc types export for battles"""

from .classes import Music
