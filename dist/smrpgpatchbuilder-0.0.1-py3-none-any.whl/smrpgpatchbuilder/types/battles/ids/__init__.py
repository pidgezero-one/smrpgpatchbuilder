"""Basic integer IDs associated with battle packs and formations"""

from .formation_ids import *
from .pack_ids import *
from .misc import TOTAL_PACKS, TOTAL_FORMATIONS
