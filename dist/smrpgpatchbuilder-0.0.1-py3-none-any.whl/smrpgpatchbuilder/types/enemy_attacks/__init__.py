"""Enemy attack related types"""

from .classes import EnemyAttack
