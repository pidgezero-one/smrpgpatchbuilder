"""Basic integer IDs associated with both event and action scripts"""

from .misc import *
from .music_names import *
from .overworld_names import *
from .room_names import *
from .shops_ids import *
from .sound_names import *
