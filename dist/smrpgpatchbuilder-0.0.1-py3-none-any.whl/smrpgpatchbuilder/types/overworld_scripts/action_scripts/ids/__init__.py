"""Basic integer IDs associated with action scripts"""

from .misc import TOTAL_SCRIPTS
from .script_ids import *
