"""Basic integer IDs associated with event scripts"""

from .misc import TOTAL_SCRIPTS, TOTAL_PACKETS
from .script_ids import *
