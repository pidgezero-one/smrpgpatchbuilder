"""Base classes for ROM patches."""

from .classes import Patch
