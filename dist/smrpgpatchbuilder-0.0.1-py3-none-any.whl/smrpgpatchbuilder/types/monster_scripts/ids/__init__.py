"""Basic integer IDs associated with monster scripts"""

from .known_variables import *
from .misc import *
