# SMRPG Patch Builder

Base classes that can create patch bytes compatible with SMRPG randomizer