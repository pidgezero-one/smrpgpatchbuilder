""""Miscellaeous constants used for enemy attack classes and functions."""

ENEMY_ATTACK_BASE_ADDRESS: int = 0x391226
