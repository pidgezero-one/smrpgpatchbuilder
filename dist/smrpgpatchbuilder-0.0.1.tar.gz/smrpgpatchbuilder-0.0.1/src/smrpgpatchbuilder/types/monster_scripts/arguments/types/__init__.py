"""Class definitions for certain restricted argument types for monster scripts."""

from .classes import Target, CommandType
