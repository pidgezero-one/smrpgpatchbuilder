"""Legal command classes that can be used in action scripts."""

from .classes import ActionScript, ActionScriptBank
