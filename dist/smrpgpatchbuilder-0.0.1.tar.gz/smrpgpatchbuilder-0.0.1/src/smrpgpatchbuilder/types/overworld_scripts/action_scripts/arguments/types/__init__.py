"""Base classes that inform argument typing in action script command classes."""

from .classes import SequenceSpeed, VRAMPriority
