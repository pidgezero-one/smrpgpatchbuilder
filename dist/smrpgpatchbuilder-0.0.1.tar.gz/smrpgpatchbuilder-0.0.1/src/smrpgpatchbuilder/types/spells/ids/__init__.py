"""Miscellaneous constants supporting the development of spells."""

from .misc import STARTING_FP, ALLY_SPELL_POINTER_TABLE_START
