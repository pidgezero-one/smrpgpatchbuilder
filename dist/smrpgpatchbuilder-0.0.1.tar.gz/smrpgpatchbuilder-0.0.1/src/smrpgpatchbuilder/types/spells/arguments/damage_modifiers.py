"""(unknown)"""

from .types import DamageModifiers


NO_MODIFIERS = DamageModifiers(0xD09B)
X00625_MODIFIER = DamageModifiers(0xD09C)
X05_MODIFIER = DamageModifiers(0xD177)
X0125_MODIFIER_WITH_MULTI_TARGETING = DamageModifiers(0xD0FB)
X00625_MODIFIER_WITH_MULTI_TARGETING = DamageModifiers(0xD14F)
