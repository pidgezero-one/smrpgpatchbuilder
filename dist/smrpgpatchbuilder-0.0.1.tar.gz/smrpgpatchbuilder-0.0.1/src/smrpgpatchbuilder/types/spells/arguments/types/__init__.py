"""Helper classes defining constants used in spell development."""

from .classes import TimingProperties, DamageModifiers
