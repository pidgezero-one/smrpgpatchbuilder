"""Dialog bank IDs"""

from .classes import DialogBankID
