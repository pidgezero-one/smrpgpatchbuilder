"""IDs related to dialogs"""

from .dialog_bank_ids import DIALOG_BANK_22, DIALOG_BANK_23, DIALOG_BANK_24
from .dialog_ids import *
from .misc import *
