"""Dialog classes"""

from .classes import Dialog, DialogCollection
