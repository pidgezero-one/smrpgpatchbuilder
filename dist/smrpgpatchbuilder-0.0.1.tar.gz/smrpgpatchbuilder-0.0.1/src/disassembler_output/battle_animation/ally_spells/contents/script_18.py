# Geno Whirl

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x3580e2"]),
	RunSubroutine(["command_0x358127"]),
	RunSubroutine(["command_0x3590a2"]),
	ReturnSubroutine()
])
