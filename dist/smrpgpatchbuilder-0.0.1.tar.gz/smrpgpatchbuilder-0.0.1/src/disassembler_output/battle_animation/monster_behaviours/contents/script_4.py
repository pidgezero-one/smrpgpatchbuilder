# behaviour_4_0x3506A7

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 89, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	UnknownCommand(bytearray(b'T')),
	UnknownCommand(bytearray(b'>')),
	DrawSpriteAtAMEM32Coords(sprite_id=SPR0003_MARIO_SURPRISE_LEFT, sequence=0, store_to_vram=True, store_palette=True, overlap_all_sprites=True),
	MoveObject(speed=1, start_position=256, end_position=0, apply_to_x=True, should_set_speed=True),
	MoveObject(speed=1, start_position=-129, end_position=0, apply_to_y=True, should_set_speed=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=8),
	ResetObjectMappingMemory(),
	MoveObject(speed=1, start_position=-257, end_position=0, apply_to_x=True, should_set_speed=True),
	MoveObject(speed=1, start_position=128, end_position=0, apply_to_y=True, should_set_speed=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=8),
	ResetObjectMappingMemory(),
	DrawSpriteAtAMEM32Coords(sprite_id=SPR0000_MARIO_WALKING_DOWN_LEFT, sequence=0, store_to_vram=True, store_palette=True, overlap_all_sprites=True),
	ResetSpriteSequence(),
	UnknownCommand(bytearray(b'W'), identifier="command_0x3506e2"),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'U')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'V')),
	JmpIfTargetEnabled(["command_0x3506fc"]),
	PlaySound(sound=S0089_COMMON_MONSTER_EXPLOSION),
	UnknownCommand(bytearray(b'\xa4')),
	SetAMEM8BitTo7E5x(0x60, 0x7E002C),
	ClearAMEM8Bit(0x61),
	ObjectQueueAtOffsetAndIndexAtAMEM60(target_address=0x3505FE),
	RemoveObject(),
	SetAMEMToAMEM16Bit(dest_amem=0x6E, upper=0x00, amem=0x62),
	UnknownCommand(bytearray(b'\x98')),
	GameOverIfNoAlliesStanding(identifier="command_0x3506fc"),
	Jmp(["command_0x3505d5"])
])
