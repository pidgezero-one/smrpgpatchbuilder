# behaviour_38_0x350D72

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 43, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	UnknownCommand(bytearray(b'T')),
	UnknownCommand(bytearray(b'n')),
	UnknownCommand(bytearray(b'>')),
	ResetSpriteSequence(),
	UnknownCommand(bytearray(b'W')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'U')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'V')),
	JmpIfTargetEnabled(["command_0x350d99"]),
	PlaySound(sound=S0176_BOSS_FADE_OUT_DEATH),
	EnableSpritesOnSubscreen(),
	UnknownCommand(bytearray(b'\x84\x00\x08')),
	UnknownCommand(bytearray(b'\x9e\x00\x00')),
	PauseScriptUntilBitsClear(0x0300),
	FadeOutSprite(duration=2),
	PauseScriptUntil(condition=FADE_4BPP_COMPLETE),
	DisableSpritesOnSubscreen(),
	UnknownCommand(bytearray(b'\xa4')),
	RemoveObject(),
	SetAMEMToAMEM16Bit(dest_amem=0x6E, upper=0x00, amem=0x62),
	GameOverIfNoAlliesStanding(identifier="command_0x350d99"),
	Jmp(["command_0x350d31"])
])
