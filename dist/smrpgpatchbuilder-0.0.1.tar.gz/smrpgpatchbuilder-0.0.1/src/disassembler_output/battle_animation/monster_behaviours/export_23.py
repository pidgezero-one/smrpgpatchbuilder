from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_23_0X350A55
from .contents.script_23 import script as script_23

bank = AnimationScriptBank(
	name = BEHAVIOUR_23_0X350A55,
	start = 0x350a55,
	end = 0x350a9c,
	scripts = [
		script_23,
	]
)
