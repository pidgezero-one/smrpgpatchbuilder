from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_6_0X350790
from .contents.script_6 import script as script_6

bank = AnimationScriptBank(
	name = BEHAVIOUR_6_0X350790,
	start = 0x350790,
	end = 0x350796,
	scripts = [
		script_6,
	]
)
