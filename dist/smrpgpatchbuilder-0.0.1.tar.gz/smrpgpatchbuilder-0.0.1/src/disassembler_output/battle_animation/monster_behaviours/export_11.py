from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_11_0X35086A
from .contents.script_11 import script as script_11

bank = AnimationScriptBank(
	name = BEHAVIOUR_11_0X35086A,
	start = 0x35086a,
	end = 0x350898,
	scripts = [
		script_11,
	]
)
