from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_24_0X350A9C
from .contents.script_24 import script as script_24

bank = AnimationScriptBank(
	name = BEHAVIOUR_24_0X350A9C,
	start = 0x350a9c,
	end = 0x350abd,
	scripts = [
		script_24,
	]
)
