from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_25_0X350ABD
from .contents.script_25 import script as script_25

bank = AnimationScriptBank(
	name = BEHAVIOUR_25_0X350ABD,
	start = 0x350abd,
	end = 0x350ad3,
	scripts = [
		script_25,
	]
)
