from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_4_0X3506A7
from .contents.script_4 import script as script_4

bank = AnimationScriptBank(
	name = BEHAVIOUR_4_0X3506A7,
	start = 0x3506a7,
	end = 0x350700,
	scripts = [
		script_4,
	]
)
