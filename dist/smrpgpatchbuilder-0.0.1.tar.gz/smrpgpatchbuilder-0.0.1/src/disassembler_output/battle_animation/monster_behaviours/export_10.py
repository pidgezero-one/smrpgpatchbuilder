from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_10_0X350830
from .contents.script_10 import script as script_10

bank = AnimationScriptBank(
	name = BEHAVIOUR_10_0X350830,
	start = 0x350830,
	end = 0x35086a,
	scripts = [
		script_10,
	]
)
