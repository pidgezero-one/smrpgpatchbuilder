from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_44_0X350E4A
from .contents.script_44 import script as script_44

bank = AnimationScriptBank(
	name = BEHAVIOUR_44_0X350E4A,
	start = 0x350e4a,
	end = 0x350e60,
	scripts = [
		script_44,
	]
)
