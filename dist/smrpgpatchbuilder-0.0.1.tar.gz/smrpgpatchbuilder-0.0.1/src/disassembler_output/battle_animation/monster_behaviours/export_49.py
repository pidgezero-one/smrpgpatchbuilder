from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_49_0X350F44
from .contents.script_49 import script as script_49

bank = AnimationScriptBank(
	name = BEHAVIOUR_49_0X350F44,
	start = 0x350f44,
	end = 0x350f4a,
	scripts = [
		script_49,
	]
)
