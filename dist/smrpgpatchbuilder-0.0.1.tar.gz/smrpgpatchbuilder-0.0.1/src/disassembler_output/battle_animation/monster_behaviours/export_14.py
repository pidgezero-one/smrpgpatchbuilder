from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_14_0X350916
from .contents.script_14 import script as script_14

bank = AnimationScriptBank(
	name = BEHAVIOUR_14_0X350916,
	start = 0x350916,
	end = 0x35091c,
	scripts = [
		script_14,
	]
)
