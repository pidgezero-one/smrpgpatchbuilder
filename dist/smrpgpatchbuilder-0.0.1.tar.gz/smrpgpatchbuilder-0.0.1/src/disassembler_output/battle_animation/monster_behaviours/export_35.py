from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_35_0X350CDC
from .contents.script_35 import script as script_35

bank = AnimationScriptBank(
	name = BEHAVIOUR_35_0X350CDC,
	start = 0x350cdc,
	end = 0x350cf2,
	scripts = [
		script_35,
	]
)
