# ENT0010_FADE_IN

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SetAMEM32ToXYZCoords(origin=CASTER_INITIAL_POSITION, x=0, y=-256, z=0, set_x=True, set_y=True, set_z=True),
	UnknownCommand(bytearray(b'\x18\x00\x80')),
	EnableSpritesOnSubscreen(),
	VisibilityOff(),
	SetAMEM32ToXYZCoords(origin=CASTER_INITIAL_POSITION, x=0, y=0, z=0, set_x=True, set_y=True, set_z=True),
	UnknownCommand(bytearray(b'\x84\x00\x08')),
	UnknownCommand(bytearray(b'\x9e\x00\x00')),
	FadeInSprite(duration=2),
	VisibilityOn(),
	PauseScriptUntil(condition=FADE_4BPP_COMPLETE),
	UnknownCommand(bytearray(b'\x84\x80\x00')),
	UnknownCommand(bytearray(b'\x9e\x00 ')),
	DisableSpritesOnSubscreen(),
	ReturnSubroutine()
])
