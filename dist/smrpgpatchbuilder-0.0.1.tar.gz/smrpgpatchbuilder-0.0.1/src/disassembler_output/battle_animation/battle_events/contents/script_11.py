# BE0011_SOLO_EARTH_CRYSTAL_APPEARS

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3abb14"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3aba5c"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3abbc6"], character_slot=True, bit_5=True),
	SpriteQueue(field_object=4, destinations=["queuestart_0x3abca8"], character_slot=True, bit_5=True),
	SpriteQueue(field_object=3, destinations=["queuestart_0x3abd7a"], character_slot=True, bit_5=True),
	RunSubroutine(["command_0x3a7734"]),
	FadeCurrentMusicToVolume(speed=2, volume=0),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3aba76"], bit_2=True, bit_4=True),
	RunSubroutine(["command_0x3a77c3"]),
	RunSubroutine(["command_0x3a771e"]),
	Jmp(["command_0x3a7550"])
])
