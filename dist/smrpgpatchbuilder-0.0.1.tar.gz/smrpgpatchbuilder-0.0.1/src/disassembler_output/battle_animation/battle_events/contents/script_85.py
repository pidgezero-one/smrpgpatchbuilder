# BE0085_FEAR_ROULETTE

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(header=["command_0x3a6d97", "command_0x3a6da8"], script = [
	RunSubroutine(["command_0x3a7531"]),
	ClearAMEM8Bit(0x60),
	SetAMEM16BitToConst(0x60, 11),
	ObjectQueueAtOffsetAndIndex(index=0, target_address=0x3A8AC0),
	RunSubroutine(["command_0x3a771e"]),
	UnknownCommand(bytearray(b'\xe2')),
	RunSubroutine(["command_0x3a7531"], identifier="command_0x3a6d97"),
	ClearAMEM8Bit(0x60),
	SetAMEM16BitToConst(0x60, 11),
	ObjectQueueAtOffsetAndIndex(index=2, target_address=0x3A8AC0),
	RunSubroutine(["command_0x3a771e"]),
	UnknownCommand(bytearray(b'\xe2')),
	RunSubroutine(["command_0x3a7531"], identifier="command_0x3a6da8"),
	ClearAMEM8Bit(0x60),
	SetAMEM16BitToConst(0x60, 11),
	ObjectQueueAtOffsetAndIndex(index=4, target_address=0x3A8AC0),
	RunSubroutine(["command_0x3a771e"]),
	UnknownCommand(bytearray(b'\xe2'))
])
