# BE0081_EXOR_IS_DEFEATED_CRIES_AND_OPENS_MOUTH

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ae0cc"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae0d9"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ae0e8"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=3, destinations=["queuestart_0x3ae0f8"], bit_2=True, bit_4=True),
	RunSubroutine(["command_0x3a7781"]),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=60),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ae110"], character_slot=True, bit_4=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=16),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae110"], character_slot=True, bit_4=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=16),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ae110"], character_slot=True, bit_4=True),
	RunSubroutine(["command_0x3a7776"]),
	Jmp(["command_0x3a7550"])
])
