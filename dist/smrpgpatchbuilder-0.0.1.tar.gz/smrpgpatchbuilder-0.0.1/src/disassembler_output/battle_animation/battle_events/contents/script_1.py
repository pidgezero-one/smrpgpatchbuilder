# BE0001_UNUSED

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	PlaySound(sound=S0078_TIMED_STAT_BOOST),
	UnknownCommand(bytearray(b'\xba\x01\x00\x00')),
	ScreenEffect(SEF0006_SCREEN_FLASHES_WHITE),
	UnknownCommand(bytearray(b'\xa8\x02\x00')),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=60),
	SetTarget(MONSTER_3_SET),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3aadd5"], current_target=True),
	SetTarget(MONSTER_4_SET),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3aa8f2"], current_target=True),
	RunSubroutine(["command_0x3a7734"]),
	SetTarget(MARIO),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3aab08"], current_target=True),
	RunSubroutine(["command_0x3a7760"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3aae13"], bit_2=True, bit_4=True),
	RunSubroutine(["command_0x3a774a"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3aae51"], bit_2=True, bit_4=True),
	RunSubroutine(["command_0x3a776b"]),
	FadeCurrentMusicToVolume(speed=3, volume=1),
	UnknownCommand(bytearray(b'\xba\x01\x83\x00')),
	ScreenEffect(SEF0006_SCREEN_FLASHES_WHITE),
	RunSubroutine(["command_0x3a77a2"]),
	UnknownCommand(bytearray(b'\xba\x01\x8d\x00')),
	ScreenEffect(SEF0006_SCREEN_FLASHES_WHITE),
	RunSubroutine(["command_0x3a77b8"]),
	UnknownCommand(bytearray(b'\xba\x01\x80\x00')),
	ScreenEffect(SEF0006_SCREEN_FLASHES_WHITE),
	RunSubroutine(["command_0x3a77ce"]),
	PlaySound(sound=S0096_RUMBLE_MULTI),
	RunSubroutine(["command_0x3a771e"]),
	StopCurrentSoundEffect(),
	Jmp(["command_0x3a7550"])
])
