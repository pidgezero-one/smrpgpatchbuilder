# BE0036_TENTACLES_THROW_CHARACTER_OFF_SCREEN

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SetAMEM8BitTo7E1x(0x60, 0x7EFA80),
	JmpIfAMEMBitsSet(0x60, [7], ["command_0x3a6711"]),
	SetAMEM8BitTo7E1x(0x60, 0x7EFB00),
	JmpIfAMEMBitsSet(0x60, [7], ["command_0x3a6711"]),
	SetAMEM8BitTo7E1x(0x60, 0x7EFB80),
	JmpIfAMEMBitsSet(0x60, [7], ["command_0x3a6711"]),
	SetTarget(RANDOM_OPPONENT),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ac917"], current_target=True),
	SetAMEM8BitTo7E1x(0x60, 0x7EE00E),
	JmpIfAMEM8BitEqualsConst(0x60, 1, ["command_0x3a66cb"]),
	JmpIfAMEM8BitEqualsConst(0x60, 2, ["command_0x3a66d3"]),
	JmpIfAMEM8BitEqualsConst(0x60, 3, ["command_0x3a66db"]),
	JmpIfAMEM8BitEqualsConst(0x60, 4, ["command_0x3a66e3"]),
	JmpIfAMEM8BitEqualsConst(0x60, 5, ["command_0x3a66eb"]),
	JmpIfAMEM8BitEqualsConst(0x60, 6, ["command_0x3a66f3"]),
	JmpIfAMEM8BitEqualsConst(0x60, 7, ["command_0x3a66fb"]),
	JmpIfAMEM8BitEqualsConst(0x60, 8, ["command_0x3a6703"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ac990"], bit_2=True, bit_4=True, identifier="command_0x3a66cb"),
	Jmp(["command_0x3a670b"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ac990"], bit_2=True, bit_4=True, identifier="command_0x3a66d3"),
	Jmp(["command_0x3a670b"]),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ac990"], bit_2=True, bit_4=True, identifier="command_0x3a66db"),
	Jmp(["command_0x3a670b"]),
	SpriteQueue(field_object=3, destinations=["queuestart_0x3ac990"], bit_2=True, bit_4=True, identifier="command_0x3a66e3"),
	Jmp(["command_0x3a670b"]),
	SpriteQueue(field_object=4, destinations=["queuestart_0x3ac990"], bit_2=True, bit_4=True, identifier="command_0x3a66eb"),
	Jmp(["command_0x3a670b"]),
	SpriteQueue(field_object=5, destinations=["queuestart_0x3ac990"], bit_2=True, bit_4=True, identifier="command_0x3a66f3"),
	Jmp(["command_0x3a670b"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ac990"], bit_2=True, bit_4=True, identifier="command_0x3a66fb"),
	Jmp(["command_0x3a670b"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ac990"], bit_2=True, bit_4=True, identifier="command_0x3a6703"),
	Jmp(["command_0x3a670b"]),
	RunSubroutine(["command_0x3a771e"], identifier="command_0x3a670b"),
	Jmp(["command_0x3a7550"]),
	ClearAMEM8Bit(0x60, identifier="command_0x3a6711"),
	Set7E1xToAMEM8Bit(0x7EE008, 0x60),
	Jmp(["command_0x3a7550"])
])
