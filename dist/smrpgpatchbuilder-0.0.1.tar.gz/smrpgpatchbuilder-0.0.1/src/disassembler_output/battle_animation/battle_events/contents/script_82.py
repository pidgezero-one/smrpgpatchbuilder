# BE0082_SMITHY_1ST_FORM_IS_BEATEN_GROUND_SHAKES_ETC

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ae6a0"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae857"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ae8ce"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=3, destinations=["queuestart_0x3ae93b"], bit_2=True, bit_4=True),
	Pause1Frame(),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ae966"], character_slot=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3aea25"], character_slot=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3aeaf0"], character_slot=True, bit_4=True),
	RunSubroutine(["command_0x3a776b"]),
	SetAMEM16BitToConst(0x60, 12),
	ObjectQueueAtOffsetAndIndex(index=34, target_address=0x3A8AC0),
	ObjectQueueAtOffsetAndIndex(index=36, target_address=0x3A8AC0),
	PlaySound(sound=S0078_TIMED_STAT_BOOST),
	UnknownCommand(bytearray(b'\xba\x01\x00\x00')),
	ScreenEffect(SEF0016_UNKNOWN),
	UnknownCommand(bytearray(b'\xa8\x02\x00')),
	SetAMEM16BitToConst(0x60, 12),
	ObjectQueueAtOffsetAndIndex(index=30, target_address=0x3A8AC0),
	ObjectQueueAtOffsetAndIndex(index=32, target_address=0x3A8AC0),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=300),
	FadeCurrentMusicToVolume(speed=3, volume=0),
	PlaySound(sound=S0078_TIMED_STAT_BOOST),
	UnknownCommand(bytearray(b'\xba\x01\x03\x00')),
	ScreenEffect(SEF0016_UNKNOWN),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=50),
	RunSubroutine(["command_0x3a7692"]),
	UnknownCommand(bytearray(b'\xba\x01\x04\x00')),
	ScreenEffect(SEF0016_UNKNOWN),
	RunSubroutine(["command_0x3a763e"]),
	RunSubroutine(["command_0x3a7826"]),
	PlayMusicAtVolume(M0069_FIGHTAGAINSTSMITHY2, 61456),
	RunSubroutine(["command_0x3a771e"]),
	UnknownCommand(bytearray(b'\xe6')),
	Jmp(["command_0x3a7550"])
])
