# BE0088_SMITHY_TRANSFORMS_INTO_MAGIC_HEAD

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ae2cd"], bit_2=True, bit_4=True),
	SetAMEM8BitTo7E1x(0x60, 0x7EE009),
	JmpIfAMEM8BitEqualsConst(0x60, 1, ["command_0x3a6e6a"]),
	JmpIfAMEM8BitEqualsConst(0x60, 2, ["command_0x3a6e72"]),
	JmpIfAMEM8BitEqualsConst(0x60, 3, ["command_0x3a6e7a"]),
	JmpIfAMEM8BitEqualsConst(0x60, 4, ["command_0x3a6e82"]),
	ClearAMEM8Bit(0x60),
	Set7E1xToAMEM8Bit(0x7EE009, 0x60),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae254"], bit_2=True, bit_4=True, identifier="command_0x3a6e6a"),
	Jmp(["command_0x3a6e8d"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae231"], bit_2=True, bit_4=True, identifier="command_0x3a6e72"),
	Jmp(["command_0x3a6e8d"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae231"], bit_2=True, bit_4=True, identifier="command_0x3a6e7a"),
	Jmp(["command_0x3a6e8d"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae277"], bit_2=True, bit_4=True, identifier="command_0x3a6e82"),
	ClearAMEM8Bit(0x60),
	Set7E1xToAMEM8Bit(0x7EE009, 0x60),
	RunSubroutine(["command_0x3a771e"], identifier="command_0x3a6e8d"),
	Jmp(["command_0x3a7550"])
])
