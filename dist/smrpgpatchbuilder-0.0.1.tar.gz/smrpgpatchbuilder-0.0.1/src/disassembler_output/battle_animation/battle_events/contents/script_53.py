# BE0053_DOMINO_TEAMS_UP_WITH_MAD_ADDER

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ad456"], bit_2=True, bit_4=True),
	RunSubroutine(["command_0x3a7734"]),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=16),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ad5c1"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ad52b"], bit_2=True, bit_4=True),
	Pause1Frame(),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ad520"], character_slot=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ad520"], character_slot=True, bit_4=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ad520"], character_slot=True, bit_4=True),
	ClearAMEM8Bit(0x60),
	SetAMEM16BitToConst(0x60, 6),
	ObjectQueueAtOffsetAndIndex(index=2, target_address=0x3A8AC0),
	RunSubroutine(["command_0x3a771e"]),
	UnknownCommand(bytearray(b'\xe6')),
	Jmp(["command_0x3a7550"])
])
