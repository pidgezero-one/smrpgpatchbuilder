from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import ITEMS
from .contents.script_0 import script as script_0
from .contents.script_1 import script as script_1
from .contents.script_2 import script as script_2
from .contents.script_3 import script as script_3
from .contents.script_4 import script as script_4
from .contents.script_5 import script as script_5
from .contents.script_6 import script as script_6
from .contents.script_7 import script as script_7
from .contents.script_8 import script as script_8
from .contents.script_9 import script as script_9
from .contents.script_10 import script as script_10
from .contents.script_11 import script as script_11
from .contents.script_12 import script as script_12
from .contents.script_13 import script as script_13
from .contents.script_14 import script as script_14
from .contents.script_15 import script as script_15
from .contents.script_16 import script as script_16
from .contents.script_17 import script as script_17
from .contents.script_18 import script as script_18
from .contents.script_19 import script as script_19
from .contents.script_20 import script as script_20
from .contents.script_21 import script as script_21
from .contents.script_22 import script as script_22
from .contents.script_23 import script as script_23
from .contents.script_24 import script as script_24
from .contents.script_25 import script as script_25
from .contents.script_26 import script as script_26
from .contents.script_27 import script as script_27
from .contents.script_28 import script as script_28
from .contents.script_29 import script as script_29
from .contents.script_30 import script as script_30
from .contents.script_31 import script as script_31
from .contents.script_32 import script as script_32
from .contents.script_33 import script as script_33
from .contents.script_34 import script as script_34
from .contents.script_35 import script as script_35
from .contents.script_36 import script as script_36
from .contents.script_37 import script as script_37
from .contents.script_38 import script as script_38
from .contents.script_39 import script as script_39
from .contents.script_40 import script as script_40
from .contents.script_41 import script as script_41
from .contents.script_42 import script as script_42
from .contents.script_43 import script as script_43
from .contents.script_44 import script as script_44
from .contents.script_45 import script as script_45
from .contents.script_46 import script as script_46
from .contents.script_47 import script as script_47
from .contents.script_48 import script as script_48
from .contents.script_49 import script as script_49
from .contents.script_50 import script as script_50
from .contents.script_51 import script as script_51
from .contents.script_52 import script as script_52
from .contents.script_53 import script as script_53
from .contents.script_54 import script as script_54
from .contents.script_55 import script as script_55
from .contents.script_56 import script as script_56
from .contents.script_57 import script as script_57
from .contents.script_58 import script as script_58
from .contents.script_59 import script as script_59
from .contents.script_60 import script as script_60
from .contents.script_61 import script as script_61
from .contents.script_62 import script as script_62
from .contents.script_63 import script as script_63
from .contents.script_64 import script as script_64
from .contents.script_65 import script as script_65
from .contents.script_66 import script as script_66
from .contents.script_67 import script as script_67
from .contents.script_68 import script as script_68
from .contents.script_69 import script as script_69
from .contents.script_70 import script as script_70
from .contents.script_71 import script as script_71
from .contents.script_72 import script as script_72
from .contents.script_73 import script as script_73
from .contents.script_74 import script as script_74
from .contents.script_75 import script as script_75
from .contents.script_76 import script as script_76
from .contents.script_77 import script as script_77
from .contents.script_78 import script as script_78
from .contents.script_79 import script as script_79
from .contents.script_80 import script as script_80

bank = AnimationScriptBank(
	name = ITEMS,
	start = 0x35c803,
	end = 0x35c968,
	pointer_table_start = 0x35c761,
	scripts = [
		script_0,
		script_1,
		script_2,
		script_3,
		script_4,
		script_5,
		script_6,
		script_7,
		script_8,
		script_9,
		script_10,
		script_11,
		script_12,
		script_13,
		script_14,
		script_15,
		script_16,
		script_17,
		script_18,
		script_19,
		script_20,
		script_21,
		script_22,
		script_23,
		script_24,
		script_25,
		script_26,
		script_27,
		script_28,
		script_29,
		script_30,
		script_31,
		script_32,
		script_33,
		script_34,
		script_35,
		script_36,
		script_37,
		script_38,
		script_39,
		script_40,
		script_41,
		script_42,
		script_43,
		script_44,
		script_45,
		script_46,
		script_47,
		script_48,
		script_49,
		script_50,
		script_51,
		script_52,
		script_53,
		script_54,
		script_55,
		script_56,
		script_57,
		script_58,
		script_59,
		script_60,
		script_61,
		script_62,
		script_63,
		script_64,
		script_65,
		script_66,
		script_67,
		script_68,
		script_69,
		script_70,
		script_71,
		script_72,
		script_73,
		script_74,
		script_75,
		script_76,
		script_77,
		script_78,
		script_79,
		script_80,
	]
)
