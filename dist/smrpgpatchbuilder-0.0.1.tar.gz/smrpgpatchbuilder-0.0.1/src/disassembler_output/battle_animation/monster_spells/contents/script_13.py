# Escape

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SetAMEM16BitToAMEM(amem=0x68, source_amem=0x6A, upper=0x30, identifier="command_0x35116a"),
	JmpIfAMEM16BitNotEqualsConst(0x68, 0, ["command_0x351179"]),
	RunSubroutine(["command_0x35322b"]),
	UnknownCommand(bytearray(b'\x16')),
	UnknownCommand(bytearray(b'\x02')),
	RunSubroutine(["command_0x353274"], identifier="command_0x351179"),
	UnknownCommand(bytearray(b'\x16')),
	UnknownCommand(bytearray(b'\x02'))
])
