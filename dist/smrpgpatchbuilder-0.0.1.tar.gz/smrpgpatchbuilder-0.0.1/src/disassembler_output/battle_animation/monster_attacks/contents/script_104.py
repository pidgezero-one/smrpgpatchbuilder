# PhysicalAttack118

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x35313b"]),
	PlaySound(sound=S0009_ARROW_SLING),
	SetAMEM16BitToConst(0x60, 21),
	RunSubroutine(["command_0x352489"]),
	ReturnSubroutine()
])
