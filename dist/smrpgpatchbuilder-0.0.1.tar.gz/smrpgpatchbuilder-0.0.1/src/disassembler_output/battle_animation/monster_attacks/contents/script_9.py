# PhysicalAttack11

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x353005"]),
	RunSubroutine(["command_0x3579a2"]),
	RunSubroutine(["command_0x352f2f"]),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=15),
	RunSubroutine(["command_0x3523c4"]),
	RunSubroutine(["command_0x357a03"]),
	ReturnSubroutine()
])
