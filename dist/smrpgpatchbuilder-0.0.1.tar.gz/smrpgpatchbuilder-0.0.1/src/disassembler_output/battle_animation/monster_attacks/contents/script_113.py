# Shaker

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x357e6c"]),
	RunSubroutine(["command_0x353148"]),
	PlaySound(sound=S0092_SPEAR_RAIN_SINGLE),
	SetAMEM16BitToConst(0x60, 16),
	RunSubroutine(["command_0x3524b1"]),
	RunSubroutine(["command_0x357e1a"]),
	ReturnSubroutine()
])
