# CarniKiss

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x352523"]),
	RunSubroutine(["command_0x357c11"]),
	RunSubroutine(["command_0x3523c4"]),
	ReturnSubroutine()
])
