# ValorUp

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x3577e2"]),
	SetOMEM60To072C(),
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	PlaySound(sound=S0021_SCARECROW_BIRDIES),
	SpriteSequence(sequence=4),
	PauseScriptUntilSpriteSequenceDone(),
	ResetSpriteSequence(),
	RunSubroutine(["command_0x3577f2"]),
	AttackTimerBegins(),
	ReturnSubroutine()
])
