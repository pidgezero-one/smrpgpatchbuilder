

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SetOMEM60To072C(),
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	RunSubroutine(["command_0x35303b"]),
	RunSubroutine(["command_0x35788e"]),
	RunBattleEvent(script_id=BE0070_JINX_USES_JINXED),
	RunSubroutine(["command_0x3535ad"]),
	RunSubroutine(["command_0x3577f2"]),
	ReturnSubroutine()
])
