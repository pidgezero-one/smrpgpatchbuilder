# PhysicalAttack111

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SetOMEM60To072C(),
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	RunSubroutine(["command_0x353155"]),
	ClearAMEM16Bit(0x60),
	ClearAMEM8Bit(0x6F),
	ClearAMEM8Bit(0x6E),
	SetAMEM8BitToConst(0x6E, 1),
	ObjectQueueAtOffsetAndIndex(index=0, target_address=0x35D2D5),
	PauseScriptUntilAMEMBitsSet(0x6F, [0]),
	ResetSpriteSequence(),
	ReturnSubroutine()
])
