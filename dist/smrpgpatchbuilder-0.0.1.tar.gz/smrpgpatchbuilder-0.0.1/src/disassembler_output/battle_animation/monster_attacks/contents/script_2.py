# PhysicalAttack4

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x357808"]),
	RunSubroutine(["command_0x353140"]),
	RunSubroutine(["command_0x3523c4"]),
	RunSubroutine(["command_0x357878"]),
	ReturnSubroutine()
])
