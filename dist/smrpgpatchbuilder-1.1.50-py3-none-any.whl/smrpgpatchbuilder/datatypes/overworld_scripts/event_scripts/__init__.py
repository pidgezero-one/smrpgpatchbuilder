# Lazy imports to avoid circular dependencies
# Use: from smrpgpatchbuilder.datatypes.overworld_scripts.event_scripts.classes import EventScript
# Instead of: from smrpgpatchbuilder.datatypes.overworld_scripts.event_scripts import EventScript
