"""Shop-related classes and utilities."""
