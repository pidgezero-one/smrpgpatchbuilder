from .classes import CommandType, DoNothing, Target
