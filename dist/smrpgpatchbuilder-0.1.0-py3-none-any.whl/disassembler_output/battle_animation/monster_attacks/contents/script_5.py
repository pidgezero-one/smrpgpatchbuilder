# PhysicalAttack7

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	PlaySound(sound=S0169_TELEPORT_ATTACK),
	RunSubroutine(["command_0x3578f1"]),
	RunSubroutine(["command_0x353140"]),
	RunSubroutine(["command_0x3523c4"]),
	RunSubroutine(["command_0x3577f2"]),
	ReturnSubroutine()
])
