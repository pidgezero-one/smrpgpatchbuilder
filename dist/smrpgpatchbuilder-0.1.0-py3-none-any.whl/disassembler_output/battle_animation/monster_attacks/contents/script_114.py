

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x353437"]),
	SetOMEM60To072C(),
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	SetAMEM16BitToConst(0x60, 4),
	ObjectQueueAtOffsetAndIndex(index=6, target_address=0x353706),
	RunSubroutine(["command_0x3533df"]),
	RunSubroutine(["command_0x357e88"]),
	PlaySound(sound=S0012_BOMB_EXPLOSION),
	RunSubroutine(["command_0x3533f5"]),
	RunSubroutine(["command_0x3523df"]),
	RunSubroutine(["command_0x3577f2"]),
	ReturnSubroutine()
])
