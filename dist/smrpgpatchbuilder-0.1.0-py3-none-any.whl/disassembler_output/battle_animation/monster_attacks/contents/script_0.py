# PhysicalAttack0

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x352f96"]),
	RunSubroutine(["command_0x3577e0"]),
	RunSubroutine(["command_0x353140"]),
	RunSubroutine(["command_0x3577e1"]),
	RunSubroutine(["command_0x3523c4"]),
	ReturnSubroutine()
])
