

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SetOMEM60To072C(),
	DisplayMessageAtOMEM60As(ATTACK_NAME),
	RunSubroutine(["command_0x357b73"]),
	PlaySound(sound=S0035_SPELL_POWER_UP),
	DrawSpriteAtAMEM32Coords(sprite_id=SPR0452_JINX_ND_TIME, sequence=4, store_to_vram=True, store_palette=True, behind_all_sprites=True, overlap_all_sprites=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=60),
	PlaySound(sound=S0102_STATIC_E),
	SetAMEM16BitToConst(0x60, 28),
	RunSubroutine(["command_0x352475"]),
	DrawSpriteAtAMEM32Coords(sprite_id=SPR0474_JINX_RD_TIME, sequence=0, store_to_vram=True, store_palette=True, behind_all_sprites=True, overlap_all_sprites=True),
	ResetSpriteSequence(),
	RunSubroutine(["command_0x3535ad"]),
	RunSubroutine(["command_0x3577f2"]),
	ReturnSubroutine()
])
