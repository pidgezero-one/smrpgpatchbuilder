# PhysicalAttack101

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	PlaySound(sound=S0004_JUMP),
	RunSubroutine(["command_0x357c7d"]),
	PlaySound(sound=S0018_SUPER_JUMP_HIT_1),
	RunSubroutine(["command_0x3523c4"]),
	RunSubroutine(["command_0x357cc3"]),
	ReturnSubroutine()
])
