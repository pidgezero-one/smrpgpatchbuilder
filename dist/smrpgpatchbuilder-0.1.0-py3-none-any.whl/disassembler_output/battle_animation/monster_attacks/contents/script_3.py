# PhysicalAttack5

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x35303b"]),
	RunSubroutine(["command_0x35788e"]),
	RunSubroutine(["command_0x353140"]),
	RunSubroutine(["command_0x3523c4"]),
	RunSubroutine(["command_0x35789e"]),
	ReturnSubroutine()
])
