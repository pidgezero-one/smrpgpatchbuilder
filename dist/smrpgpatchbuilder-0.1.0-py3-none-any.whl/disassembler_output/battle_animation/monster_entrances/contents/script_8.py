# ENT0008_HOVER_IN

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	SetAMEM32ToXYZCoords(origin=CASTER_INITIAL_POSITION, x=100, y=-50, z=0, set_x=True, set_y=True, set_z=True),
	UnknownCommand(bytearray(b'\x18\x00\x80')),
	ResetSpriteSequence(),
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	MoveObject(speed=1, start_position=-769, end_position=-513, apply_to_x=True, should_set_end_position=True, should_set_speed=True),
	MoveObject(speed=1, start_position=384, end_position=256, apply_to_y=True, should_set_end_position=True, should_set_speed=True),
	MoveObject(speed=1, start_position=-161, end_position=0, apply_to_z=True, should_set_end_position=True, should_set_speed=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=8),
	MoveObject(speed=1, start_position=160, end_position=0, apply_to_z=True, should_set_end_position=True, should_set_speed=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=8),
	MoveObject(speed=1, start_position=-161, end_position=0, apply_to_z=True, should_set_end_position=True, should_set_speed=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=8),
	MoveObject(speed=1, start_position=160, end_position=0, apply_to_z=True, should_set_end_position=True, should_set_speed=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=8),
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	SetAMEM40ToXYZCoords(origin=CASTER_INITIAL_POSITION, x=0, y=0, z=0, set_x=True, set_y=True, set_z=True),
	MoveSpriteToCoords(shift_type=SHIFT_TYPE_0X00, speed=768, arch_height=0),
	PauseScriptUntil(condition=UNKNOWN_PAUSE_4),
	ResetObjectMappingMemory(),
	ReturnSubroutine()
])
