# Once Again!

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	InitializeBonusMessageSequence(),
	DisplayBonusMessage(message=BM_ONCE, x=0, y=-32),
	DisplayBonusMessage(message=BM_AGAIN, x=4, y=-24),
	PauseScriptUntilBonusMessageComplete(),
	ReturnSubroutine()
])
