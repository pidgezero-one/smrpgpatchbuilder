# Lucky!

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	InitializeBonusMessageSequence(),
	DisplayBonusMessage(message=BM_LUCKY, x=2, y=-32),
	PauseScriptUntilBonusMessageComplete(),
	ReturnSubroutine()
])
