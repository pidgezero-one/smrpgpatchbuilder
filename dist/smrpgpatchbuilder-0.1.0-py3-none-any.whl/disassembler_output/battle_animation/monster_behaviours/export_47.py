from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_47_0X350EEE
from .contents.script_47 import script as script_47

bank = AnimationScriptBank(
	name = BEHAVIOUR_47_0X350EEE,
	start = 0x350eee,
	end = 0x350f1a,
	scripts = [
		script_47,
	]
)
