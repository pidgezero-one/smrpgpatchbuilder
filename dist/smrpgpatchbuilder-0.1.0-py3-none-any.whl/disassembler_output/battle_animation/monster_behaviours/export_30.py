from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_30_0X350BF9
from .contents.script_30 import script as script_30

bank = AnimationScriptBank(
	name = BEHAVIOUR_30_0X350BF9,
	start = 0x350bf9,
	end = 0x350bfd,
	scripts = [
		script_30,
	]
)
