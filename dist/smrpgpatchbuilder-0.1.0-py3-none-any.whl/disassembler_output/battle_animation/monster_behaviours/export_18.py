from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_18_0X35099D
from .contents.script_18 import script as script_18

bank = AnimationScriptBank(
	name = BEHAVIOUR_18_0X35099D,
	start = 0x35099d,
	end = 0x3509d5,
	scripts = [
		script_18,
	]
)
