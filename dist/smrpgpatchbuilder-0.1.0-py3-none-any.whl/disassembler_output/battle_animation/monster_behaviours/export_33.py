from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_33_0X350C5B
from .contents.script_33 import script as script_33

bank = AnimationScriptBank(
	name = BEHAVIOUR_33_0X350C5B,
	start = 0x350c5b,
	end = 0x350c9e,
	scripts = [
		script_33,
	]
)
