from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_15_0X35091C
from .contents.script_15 import script as script_15

bank = AnimationScriptBank(
	name = BEHAVIOUR_15_0X35091C,
	start = 0x35091c,
	end = 0x350928,
	scripts = [
		script_15,
	]
)
