from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_29_0X350BF3
from .contents.script_29 import script as script_29

bank = AnimationScriptBank(
	name = BEHAVIOUR_29_0X350BF3,
	start = 0x350bf3,
	end = 0x350bf9,
	scripts = [
		script_29,
	]
)
