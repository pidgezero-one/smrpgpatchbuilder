from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_43_0X350E38
from .contents.script_43 import script as script_43

bank = AnimationScriptBank(
	name = BEHAVIOUR_43_0X350E38,
	start = 0x350e38,
	end = 0x350e4a,
	scripts = [
		script_43,
	]
)
