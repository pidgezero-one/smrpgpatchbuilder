# behaviour_13_0x3508BA

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 37, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	UnknownCommand(bytearray(b'T')),
	UnknownCommand(bytearray(b'n')),
	UnknownCommand(bytearray(b'>')),
	ResetSpriteSequence(),
	UnknownCommand(bytearray(b'W')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'U')),
	UnknownCommand(bytearray(b';')),
	UnknownCommand(bytearray(b'V')),
	JmpIfTargetEnabled(["command_0x3508db"]),
	PlaySound(sound=S0089_COMMON_MONSTER_EXPLOSION, identifier="command_0x3508c8"),
	UnknownCommand(bytearray(b'Z')),
	UnknownCommand(bytearray(b'\xa4')),
	SetAMEM8BitTo7E5x(0x60, 0x7E002C),
	ClearAMEM8Bit(0x61),
	ObjectQueueAtOffsetAndIndexAtAMEM60(target_address=0x3508DF),
	RemoveObject(),
	SetAMEMToAMEM16Bit(dest_amem=0x6E, upper=0x00, amem=0x62),
	UnknownCommand(bytearray(b'\x98')),
	GameOverIfNoAlliesStanding(identifier="command_0x3508db"),
	Jmp(["command_0x3508b5"])
])
