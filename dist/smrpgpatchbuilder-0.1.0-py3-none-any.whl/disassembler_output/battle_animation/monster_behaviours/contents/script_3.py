# behaviour_3_0x350669

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = SubroutineOrBanklessScript(expected_size = 62, script = [
	ResetTargetMappingMemory(),
	ResetObjectMappingMemory(),
	UnknownCommand(bytearray(b'T')),
	UnknownCommand(bytearray(b'>')),
	DrawSpriteAtAMEM32Coords(sprite_id=SPR0015_BOWSER_SURPRISE, sequence=0, store_to_vram=True, store_palette=True, overlap_all_sprites=True),
	MoveObject(speed=1, start_position=256, end_position=0, apply_to_x=True, should_set_speed=True),
	MoveObject(speed=1, start_position=-129, end_position=0, apply_to_y=True, should_set_speed=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=8),
	ResetObjectMappingMemory(),
	MoveObject(speed=1, start_position=-257, end_position=0, apply_to_x=True, should_set_speed=True),
	MoveObject(speed=1, start_position=128, end_position=0, apply_to_y=True, should_set_speed=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=8),
	ResetObjectMappingMemory(),
	DrawSpriteAtAMEM32Coords(sprite_id=SPR0013_BOWSER_WALKING_DOWN_LEFT, sequence=0, store_to_vram=True, store_palette=True, overlap_all_sprites=True),
	ResetSpriteSequence(),
	Jmp(["command_0x3506e2"])
])
