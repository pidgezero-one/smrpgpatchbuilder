from smrpgpatchbuilder.datatypes.battle_animation_scripts.types import AnimationScriptBank
from smrpgpatchbuilder.datatypes.battle_animation_scripts.ids.bank_names import BEHAVIOUR_3_0X350669
from .contents.script_3 import script as script_3

bank = AnimationScriptBank(
	name = BEHAVIOUR_3_0X350669,
	start = 0x350669,
	end = 0x3506a7,
	scripts = [
		script_3,
	]
)
