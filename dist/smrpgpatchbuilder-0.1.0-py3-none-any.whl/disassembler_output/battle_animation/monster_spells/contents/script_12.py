# IceRock

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	RunSubroutine(["command_0x3536f8"]),
	RunSubroutine(["command_0x35252b"]),
	PlaySound(sound=S0198_ICE_ROCK),
	SetAMEM16BitToConst(0x60, 9),
	RunSubroutine(["command_0x352489"]),
	RunSubroutine(["command_0x3536ff"]),
	ReturnSubroutine()
])
