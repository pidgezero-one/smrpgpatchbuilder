# WiltShroom

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = AnimationScript([
	Set7E1xToAMEM16Bit(0x7EE022, 0x60),
	RunSubroutine(["command_0x35ceb3"]),
	RunSubroutine(["command_0x35c968"]),
	ReturnSubroutine()
])
