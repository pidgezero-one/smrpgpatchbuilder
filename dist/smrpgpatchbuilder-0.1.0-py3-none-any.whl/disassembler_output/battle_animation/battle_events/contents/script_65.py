# BE0065_UNUSED

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=4, destinations=["queuestart_0x3adbe0"], bit_2=True, bit_4=True),
	SetAMEM8BitTo7E1x(0x60, 0x7EE00F),
	JmpIfAMEM8BitEqualsConst(0x60, 5, ["command_0x3a6ac7"]),
	SpriteQueue(field_object=3, destinations=["queuestart_0x3adbff"], bit_2=True, bit_4=True),
	Jmp(["command_0x3a6acc"]),
	SpriteQueue(field_object=3, destinations=["queuestart_0x3adc54"], bit_2=True, bit_4=True, identifier="command_0x3a6ac7"),
	Jmp(["command_0x3a7550"], identifier="command_0x3a6acc")
])
