# BE0020_SOLO_WATER_CRYSTAL_APPEARS

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3abffb"], character_slot=True, bit_4=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=20),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3abfff"], character_slot=True, bit_4=True),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=20),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ac003"], character_slot=True, bit_4=True),
	RunSubroutine(["command_0x3a771e"]),
	Jmp(["command_0x3a7550"])
])
