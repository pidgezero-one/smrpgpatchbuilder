# BE0017_UNUSED

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3abe5f"], bit_2=True, bit_4=True, bit_7=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3abe5f"], bit_2=True, bit_4=True, bit_7=True),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3abe98"], character_slot=True, bit_4=True, bit_7=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3abec0"], character_slot=True, bit_4=True, bit_7=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3abee8"], character_slot=True, bit_4=True, bit_7=True),
	UnknownCommand(bytearray(b'\x18\x00\x80')),
	RunSubroutine(["command_0x3a771e"]),
	Jmp(["command_0x3a7550"])
])
