# BE0000_UNUSED

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=4, destinations=["queuestart_0x3aa6a7"], character_slot=True, bit_5=True),
	SetTarget(MONSTER_1_SET),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3aa763"], current_target=True),
	RunSubroutine(["command_0x3a7755"]),
	PauseScriptUntil(condition=FRAMES_ELAPSED, frames=20),
	ClearAMEM8Bit(0x60),
	SetAMEM16BitToConst(0x60, 0),
	ObjectQueueAtOffsetAndIndex(index=0, target_address=0x3A8AC0),
	RunSubroutine(["command_0x3a7729"]),
	Jmp(["command_0x3a7550"])
])
