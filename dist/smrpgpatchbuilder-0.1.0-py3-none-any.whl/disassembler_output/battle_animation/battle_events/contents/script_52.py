# BE0052_INTRO_SCENE_DOMINO_CLOAKER_S_INTRODUCTION

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	UnknownCommand(bytearray(b'\xba\x03(\x00\x00\x00x\xff')),
	ScreenEffect(SEF0013_SET_BATTLEFIELD_COORDS),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ad6f4"], character_slot=True, bit_4=True, bit_7=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ad703"], character_slot=True, bit_4=True, bit_7=True),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ad70e"], character_slot=True, bit_4=True, bit_7=True),
	UnknownCommand(bytearray(b'\x18\x00\x80')),
	RunSubroutine(["command_0x3a756c"]),
	SpriteQueue(field_object=0, destinations=["queuestart_0x3ad78b"], bit_2=True, bit_4=True),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ad7a3"], bit_2=True, bit_4=True),
	RunSubroutine(["command_0x3a771e"]),
	Jmp(["command_0x3a7550"])
])
