# BE0084_SCREEN_FLASHES_WHITE

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	UnknownCommand(bytearray(b'\xba\x01\x04\x00')),
	ScreenEffect(SEF0016_UNKNOWN),
	Jmp(["command_0x3a7550"])
])
