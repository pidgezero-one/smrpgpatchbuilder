# BE0090_SMITHY_TRANSFORMS_INTO_BOX_HEAD

from smrpgpatchbuilder.datatypes.battle_animation_scripts import *
from smrpgpatchbuilder.datatypes.enemies.implementations import *
from smrpgpatchbuilder.datatypes.items.implementations import *

script = BattleAnimationScript(script=[
	RunSubroutine(["command_0x3a7531"]),
	SpriteQueue(field_object=2, destinations=["queuestart_0x3ae2cd"], bit_2=True, bit_4=True),
	SetAMEMToRandomByte(amem=0x60, upper_bound=4),
	JmpIfAMEM8BitEqualsConst(0x60, 0, ["command_0x3a6f0d"]),
	JmpIfAMEM8BitEqualsConst(0x60, 1, ["command_0x3a6f15"]),
	JmpIfAMEM8BitEqualsConst(0x60, 2, ["command_0x3a6f1d"]),
	JmpIfAMEM8BitEqualsConst(0x60, 3, ["command_0x3a6f25"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae20e"], bit_2=True, bit_4=True, identifier="command_0x3a6f0d"),
	Jmp(["command_0x3a6f2a"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae231"], bit_2=True, bit_4=True, identifier="command_0x3a6f15"),
	Jmp(["command_0x3a6f2a"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae254"], bit_2=True, bit_4=True, identifier="command_0x3a6f1d"),
	Jmp(["command_0x3a6f2a"]),
	SpriteQueue(field_object=1, destinations=["queuestart_0x3ae277"], bit_2=True, bit_4=True, identifier="command_0x3a6f25"),
	RunSubroutine(["command_0x3a771e"], identifier="command_0x3a6f2a"),
	Jmp(["command_0x3a7550"])
])
