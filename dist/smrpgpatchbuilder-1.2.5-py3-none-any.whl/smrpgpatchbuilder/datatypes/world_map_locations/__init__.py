"""World Map Locations module for SMRPG."""
